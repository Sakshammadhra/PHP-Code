<?php

    $x = 10;
    echo "$x <br>";
    
    $x = 20;
    $x += 30;
    echo "$x <br>";
    
    $x = 50;
    $x -= 20;
    echo "$x <br>";
    
    $x = 5;
    $x *= 25;
    echo "$x <br>";
    
    $x = 50;
    $x /= 10;
    echo "$x <br>";
    
    $x = 100;
    $x %= 15;
    echo "$x <br>";

    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
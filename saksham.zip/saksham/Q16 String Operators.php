<?php

    $x = "Hello";
    $y = " World!";
    echo $x . $y; // Outputs: Hello World!
    echo "<br>";
    $x .= $y;
    echo $x; // Outputs: Hello World!

    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
<?php
echo str_replace("world","Dolly","Hello world!"); echo "<br>";
echo strrev("Hello world!"); echo "<br>";
echo strtolower("Hello WORLD!"); echo "<br>";
echo strtoupper("Hello WORLD!"); echo "<br>";
echo ucfirst("hello world!"); echo "<br>";
echo ucwords("hello world!"); echo "<br>";
echo strpos("Hello world!","world"); echo "<br>";
echo substr("Hello world",6); echo "<br>";
echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>

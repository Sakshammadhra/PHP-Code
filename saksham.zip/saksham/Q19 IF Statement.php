<?php

    $a = 10;
    $b = 20;
    if($a < $b)
    {
    	echo "Out of $a and $b, $a is smaller.." ;
    }
    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
<?php

    $a = 45;
    $b = 70;
    
    if ($a > $b)
    {
        echo "$a is bigger than $b";
    } 
    elseif ($a == $b)
    {
        echo "$a is equal to $b";
    }
    else 
    {
        echo "$a is smaller than $b";
    }
    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
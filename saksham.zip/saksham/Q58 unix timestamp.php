<?php
$t = time();
$fd = date('Y-m-d H:i:s', $t);

echo "Unix Timestamp: " . $t . "<br>";
echo "Formatted Date: " . $fd . "<br>";
echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>

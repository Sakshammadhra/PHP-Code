<?php
$arr = [10, 3, 5, 8, 1];

// Display the original array
echo "Original array:<br>";
foreach ($arr as $value) {
    echo $value . "<br>";
}

// Sort the array in ascending order
sort($arr);

// Display the sorted array
echo "<br>Sorted array (in ascending order):<br>";
foreach ($arr as $value) {
    echo $value . "<br>";
}
echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>

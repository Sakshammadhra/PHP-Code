<?php

    $x = 10;
    $y = 4;
    
    echo "$x + $y = ". ($x + $y) . "<br>";
    echo "$x - $y = ". ($x - $y) . "<br>";
    echo "$x * $y = ". ($x * $y) . "<br>";
    echo "$x / $y = ". ($x / $y) . "<br>";
    echo "$x % $y = ". ($x % $y) . "<br>";

    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>






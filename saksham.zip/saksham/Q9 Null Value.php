<?php

    $a = NULL;
    var_dump($a);
     
    $b = "Hello World!";
    $b = NULL;
    var_dump($b);
    
    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
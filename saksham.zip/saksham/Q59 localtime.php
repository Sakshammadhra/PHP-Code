<?php
print_r(localtime());
echo "<br><br>";
print_r(localtime(time(),true));
echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
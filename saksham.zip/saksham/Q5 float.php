<?php
    $a = 1.234;
    var_dump($a);
    
    $b = 10.2e3;
    var_dump($b);

    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
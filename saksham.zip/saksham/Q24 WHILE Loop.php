<?php

    $i = 1;
    while ($i <= 10)
    {
        echo $i;  
        echo "\t";
        $i++;
    }
    echo("<br>This program is written by Yash Jain<br>ERPID-0221BCA010");
?>
<?php

	echo 'Current PHP version: ' . phpversion();

	echo("<br>This program is written by Yash Jain<br>ERPID-0221BCA010");	
?>
<?php

    function test(){
         $greet="Hello World!";
         echo $greet;
}

test();
echo $greet;
echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>

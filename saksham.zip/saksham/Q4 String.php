<?php

    $a = "Hello world!\n";
    echo $a;
     
    $b = "Hello world!\n";
    echo $b;
     
    $c = "Stay here, I'll be back.";
    echo $c;

    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
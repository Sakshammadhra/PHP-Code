<html>
    <head>
        <title>Writing user defined function</title>
    </head>
    <body>
        <?php
        function writeMessage() {
            echo "You are really a nice person, have a good day :)<br>";
        }
        writeMessage();
        echo("<br>This program is written by Yash Jain<br>ERPID-0221BCA010");
        ?>
    </body>
</html>
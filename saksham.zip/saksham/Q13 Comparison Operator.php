<?php

    $x = 25;
    $y = 35;
    $z = "25";
    
    var_dump($x == $z); 
    var_dump($x === $z);
    var_dump($x != $y); 
    var_dump($x !== $z);
    var_dump($x < $y);  
    var_dump($x > $y);  
    var_dump($x <= $y); 
    var_dump($x >= $y); 

    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
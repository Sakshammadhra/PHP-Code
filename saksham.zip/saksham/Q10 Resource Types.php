<?php

    // Open a file for reading
    $handle = fopen("note.txt", "r");
    var_dump($handle);

    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
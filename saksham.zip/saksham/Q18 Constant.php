<?php

    define("GREETING", "hello world!");
    echo GREETING;
    echo "<br>";
    echo GREETING;
    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
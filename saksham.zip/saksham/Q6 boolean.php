<?php
    // Assign the value TRUE to a variable
    $show_error = true;
    var_dump($show_error);
    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
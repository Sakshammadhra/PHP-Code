<?php

    $a = 20;
    $b = 15;
    
    if ($a > $b)
    {
       	echo "$a is bigger than $b";
    }
    else
    {
     	echo "$a is NOT bigger than $b";
    }
    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");?>
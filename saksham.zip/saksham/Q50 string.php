<?php

    $my_str = 'World';
    echo "Hello, $my_str!<br>";

    echo("This program is written by Saksham Madhra<br>ERPID-0221BCA164");
?>
